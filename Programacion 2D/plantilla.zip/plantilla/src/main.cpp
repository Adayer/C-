
#define LITE_GFX_IMPLEMENTATION

#include <litegfx.h>
#include <glfw3.h>
#include <iostream>

using namespace std;

int main() {
	

		

    return 0;
}
