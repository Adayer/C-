// Copyright Epic Games, Inc. All Rights Reserved.

#include "CPP2_Pizza.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, CPP2_Pizza, "CPP2_Pizza" );
 