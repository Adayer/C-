#include <conio.h>
#include <windows.h>

void gotoxy			(int x, int y);
void hidecursor	(void);
void clear			();