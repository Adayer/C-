#pragma once

void Init();
void Update();
void Exit();