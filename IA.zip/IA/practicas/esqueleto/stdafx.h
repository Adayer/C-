#include <moaicore/pch.h>
#include <moaicore/MOAIGfxDevice.h>
#include <moaicore/MOAIDraw.h>
#include <moaicore/MOAIEntity2D.h>
