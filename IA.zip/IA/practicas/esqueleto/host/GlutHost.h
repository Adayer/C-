// Copyright (c) 2010-2011 Zipline Games, Inc. All Rights Reserved.
// http://getmoai.com

#ifndef	GLUTHOST
#define	GLUTHOST

//----------------------------------------------------------------//
int		GlutHost				( int argc, char** arg );
void	GlutRefreshContext		();

#endif
