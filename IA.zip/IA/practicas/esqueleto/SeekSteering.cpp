#include "stdafx.h"
#include "SeekSteering.h"
#include "character.h"

USVec2D SeekSteering::GetSteering(Character& _char, USVec2D _targetPos)
{
	USVec2D newAcc(0.f, 0.f);

	//Target Velocity
	USVec2D location(_char.GetLoc());
	debugLocation = location;
	USVec2D targetVelocity(_targetPos - location);
	targetVelocity.Norm();
	targetVelocity *= _char.GetParams()->max_velocity;
	debugTargetVelocity = targetVelocity;
	//Calculate Acceleration to reach target velocity
	newAcc = debugTargetVelocity - _char.GetLinearVelocity();
	debugLinearVelocity = _char.GetLinearVelocity();
	//Limit Acceleration to max_acceleration
	newAcc.Norm();
	newAcc = (newAcc * _char.GetParams()->max_acceleration);
	debugAcceleration = newAcc;

	return newAcc;
}

void SeekSteering::DrawDebug()
{
	MOAIGfxDevice& gfxDevice = MOAIGfxDevice::Get();
	//Target Velocity
	gfxDevice.SetPenColor(1.0f, 0.0f, 0.0f, 0.5f);
	MOAIDraw::DrawLine(debugLocation, debugLocation + debugTargetVelocity);

	//CurrentVelocity
	gfxDevice.SetPenColor(0.0f, 0.0f, 1.0f, 0.5f);
	MOAIDraw::DrawLine(debugLocation, debugLocation + debugLinearVelocity);


	//Acceleration
	gfxDevice.SetPenColor(0.0f, 1.0f, 0.0f, 0.5f);
	MOAIDraw::DrawLine(debugLocation + debugLinearVelocity, debugLocation + debugLinearVelocity + debugAcceleration);
}