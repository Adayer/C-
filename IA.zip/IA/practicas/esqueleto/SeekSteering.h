#pragma once
class Character;
class SeekSteering 
{
public:
	USVec2D GetSteering(Character& _char, USVec2D _targetPos);
	void DrawDebug();

private:

	USVec2D debugLocation;
	USVec2D debugTargetVelocity;
	USVec2D debugLinearVelocity;
	USVec2D debugAcceleration;
	Character* debugChar;

};