#include "exercise3.h"

bool Exercise3::isInputEnabled  = false;
double Exercise3::mousePosX, Exercise3::mousePosY;
double Exercise3::prevMousePosX, Exercise3::prevMousePosY;
