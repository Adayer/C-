#include "exercise2.h"

bool Exercise2::isInputEnabled  = true;
double Exercise2::mousePosX, Exercise2::mousePosY;
double Exercise2::prevMousePosX, Exercise2::prevMousePosY;