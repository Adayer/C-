#pragma once

#define STB_IMAGE_IMPLEMENTATION


#include <vector>
#include "Buffer.h"

class Shader;
class Vertex;

class Engine3D
{
public:
	Engine3D() {}
	void Init();
};