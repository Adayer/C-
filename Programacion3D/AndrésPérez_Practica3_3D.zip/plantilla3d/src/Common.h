#pragma once
class Common
{
};

