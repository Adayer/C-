#pragma once
#include "stdafx.h"
#include "sys.h"
#include "core.h"
#include "vector2d.h"
#include "Managers.h"

void InitRenderer();
void UpdateRenderer();
void ExitRenderer();

