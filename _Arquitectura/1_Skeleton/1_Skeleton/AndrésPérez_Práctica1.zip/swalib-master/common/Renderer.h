#pragma once

#include "stdafx.h"
#include "sys.h"
#include "core.h"
#include "vector2d.h"
#include "BallLogic.h"

void InitRenderer();
void UpdateRenderer();
void ExitRenderer();